<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Consultancy;
use App\Models\Roster;
use App\Models\Staff;
use App\Project;
use Illuminate\Support\Facades\Input;

class ConsultancyController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $services = Consultancy::all();

        return view('consultancy.index', compact('services'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $data['staff_name']    = Staff::pluck('name', 'id');
         $data['projects']      = Project::pluck('project_name', 'id');
         $data['consultant_name']      = Roster::pluck('fullname', 'id');
        // dd($data);
        return view('consultancy.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
     {
      // dd($request->all());
        $this->validate($request,[
            'consultant_id'          => 'required',
            'type'                   => 'required',
            'hired_date'             => 'required',
            'duration'               => 'required',
            'total_fee'              => 'required|numeric',
            'contract_signed_date'   => 'required',
            'delivery_date'          => 'required',
            'tor_text'               => 'required',
            'contract_document'      => 'required|mimes:doc,pdf,docx',
            'tor_document'           => 'required|mimes:doc,pdf,docx',
            // 'project_id'             => 'required_if|project_if',
            // 'department_name'        => 'required_if|department_if',
            'product_url'            => 'required',
            'qow'                    => 'required',
            'timely_delivery'        => 'required',
            'staff_id'               => 'required',
            'scope'                  => 'required',  
        ]);

        Consultancy::createModel($request);
        return redirect()->route('consultancy.index')->withFlashSuccess('Consultancy Service has been added successfully.');
    }

    public function show($id)
    {
         dd('show');//
    }

    public function edit($id)
    {
        // dd('here');
        $data['service']    = Consultancy::findOrFail($id);
        $data['staff_name'] = Staff::pluck('name', 'id');
        $data['projects']   = Project::pluck('project_name', 'id');
        $data['consultant_name']      = Roster::pluck('fullname', 'id');

        // dd($data);
        return view('consultancy.edit',$data);
    }

    public function update(Request $request, $id)
    {
         // dd($request->all());
        $this->validate($request,[
            
            'consultant_id'          => 'required',
            'type'                   => 'required',
            'hired_date'             => 'required',
            'duration'               => 'required',
            'total_fee'              => 'required|numeric',
            'contract_signed_date'   => 'required',
            'delivery_date'          => 'required',
            'tor_text'               => 'required',
            'contract_document'      => 'mimes:doc,pdf,docx',
            'tor_document'           => 'mimes:doc,pdf,docx',
            // 'project_id'             => 'required_if|project_if',
            // 'department_name'        => 'required_if|department_if',
            'product_url'            => 'required',
            'qow'                    => 'required',
            'timely_delivery'        => 'required',
            'staff_id'             => 'required',
            'scope'                  => 'required', 
           
        ]);

        Consultancy::updateModel($request, $id);
        // dd($request);
        return redirect()->route('consultancy.index')->withFlashSuccess('Information updated successfully.');
    }

    public function destroy($id)
    {
        $model = Consultancy::findOrFail($id);
        
        $contract_document = public_path().'/files/consultancy_service/'.$model->contract_document;
        $tor_document = public_path().'/files/consultancy_service/'.$model->tor_document;

        // dd($contract_document, $tor_document);
        \File::delete($contract_document, $tor_document);
        
         $model->delete();
        return redirect()->route('consultancy.index')->withFlashSuccess('Information Deleted successfully.');
    }
}
