<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use App\Models\DIP;
use App\Project;
use App\Models\Activity;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

class DIPController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
       $posts = DIP::all();

         return view('dip.index', compact('posts','pageheader'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        // $activity = Activity::all();
         $activity = Activity::pluck('name', 'id');
        $project_code = Project::pluck('project_code', 'id');
        // dd($project_code);
        return view('dip/create', compact('activity','project_code'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){
         // dd($request->all());
        $this->validate($request,[
            'name' => 'required',
            'act_type' => 'required',
            'obj' => 'required',
            'outcome' => 'required',
            'ind_act' => 'required',
            'ind_no' => 'required',
            'police_str' => 'required',
            'imp_date' => 'required',
        ]);

            $input = Input::all();


            if ( ($input['target_grp']) != 'others'){
                $target =  '';
            }else{
                $target = $input['tg_others'];
            }
            
           
            foreach($input['i_partners'] as $key=>$value){
                if($input['i_partners'][$key]== null){
                    unset($input['i_partners'][$key]);
                }
            }
            foreach($input['c_partners'] as $key=>$value){
                if($input['c_partners'][$key]== null){
                    unset($input['c_partners'][$key]);
                }
            }
            foreach($input['r_persons'] as $key=>$value){
                if($input['r_persons'][$key]== null){
                    unset($input['r_persons'][$key]);
                    unset($input['res_p'][$key]);
                }
            }
            foreach($input['res_p'] as $key=>$value){
                if($input['res_p'][$key]== null){
                    unset($input['res_p'][$key]);
                    unset($input['r_persons'][$key]);
                }
            } 


            $act_type= implode(", ",$input['act_type']);
                  
            $i_partners= implode(",",$input['i_partners']);
            $c_partners= implode(",",$input['c_partners']);
            
            $r_persons= implode(",",$input['r_persons']);
            $res_p= implode(",",$input['res_p']);


            $event = DIP::create([
                        'project_code' => $input['project_code'],
                        'name' => $input['name'],
                        'act_type' => $act_type,
                        'act_others' => $input['act_others'],
                        'obj' => $input['obj'],
                        'outcome' => $input['outcome'],
                        'ind_act' =>  $input['ind_act'],
                        'ind_no' =>  $input['ind_no'],
                        'police_str' => $input['police_str'],
                        'imp_date' => $input['imp_date'],
                        'imp_area' => $input['imp_area'],
                         
                        'eb_female' => $input['eb_female'],
                        'eb_male' => $input['eb_male'],
                        'eb_total' => $input['eb_total'],
                         
                         
                        'pb_travel' => $input['pb_travel'],
                        'pb_accom' => $input['pb_accom'],
                        'pb_program' => $input['pb_program'],
                        'pb_total' => $input['pb_total'],

                        'target_grp' => $input['target_grp'],
                        'tg_others' => $target,
                        'i_partners' => $i_partners,
                        'c_partners' => $c_partners,
                        'r_persons' => $r_persons,
                        'res_p'=> $res_p,

                        'ct_name' => $input['ct_name'],
                        'ct_pos' => $input['ct_pos'],
                        'ct_cell' => $input['ct_cell'],

                ]);
        
            return redirect()->route('dips.index')->withFlashSuccess('DIP has been added successfully.');

        //Project::create($request->all());
       // return redirect()->route('home')->with('message','Project has been added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
         $activity = Activity::pluck('name', 'id');
        $project_code = Project::pluck('project_code', 'id');
       
 
        $pageheader ="Edit DIP";
        $posts = DIP::findOrFail($id);

         $act_type_id      = explode(", ", $posts->act_type);


        $i_p= DIP::select('i_partners')->where('id',$id)->get();
        $i_partners= explode(',',$i_p[0]->i_partners);

        $c_p= DIP::select('c_partners')->where('id',$id)->get();
        $c_partners= explode(',',$c_p[0]->c_partners);

        $r_p= DIP::select('r_persons')->where('id',$id)->get();
        $r_persons= explode(',',$r_p[0]->r_persons);
        $r_persons_count= count($r_persons);
        
        $res= DIP::select('res_p')->where('id',$id)->get();
        $res_p= explode(',',$res[0]->res_p);
        //$r_persons= explode(',',$r_p[0]->r_persons);

// dd($act_type_id);
        return view('dip.edit', compact('posts', 'pageheader','i_partners','c_partners','r_persons','res_p','r_persons_count','activity','project_code','act_type_id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update($id, Request $request)
    {
        // dd($request->all());
       $this->validate($request,[
            'name' => 'required',
            'act_type' => 'required',
            'obj' => 'required',
            'outcome' => 'required',
            'ind_act' => 'required',
            'ind_no' => 'required',
            'police_str' => 'required',
            'imp_date' => 'required',
        ]);

            $input = Input::all();

 
            if ( ($input['target_grp']) != 'others'){
                $target =  '';
            }else{
                $target = $input['tg_others'];
            }
            
             $act_type= implode(", ",$input['act_type']);

            $i_partners= implode(",",$input['i_partners']);
            $c_partners= implode(",",$input['c_partners']);
            
            $r_persons= implode(",",$input['r_persons']);
            $res_p= implode(",",$input['res_p']);

        $event = DIP::where('id',$id)->update([
                        'project_code' => $input['project_code'],
                        'name' => $input['name'],
                        'act_type' => $act_type,
                        'act_others' => $input['act_others'],
                        'obj' => $input['obj'],
                        'outcome' => $input['outcome'],
                        'ind_act' =>  $input['ind_act'],
                        'ind_no' =>  $input['ind_no'],
                        'police_str' => $input['police_str'],
                        'imp_date' => $input['imp_date'],
                        'imp_area' => $input['imp_area'],
                         
                        'eb_female' => $input['eb_female'],
                        'eb_male' => $input['eb_male'],
                        'eb_total' => $input['eb_total'],
                         
                         
                        'pb_travel' => $input['pb_travel'],
                        'pb_accom' => $input['pb_accom'],
                        'pb_program' => $input['pb_program'],
                        'pb_total' => $input['pb_total'],

                        'target_grp' => $input['target_grp'],
                        'tg_others' => $target,
                        'i_partners' => $i_partners,
                        'c_partners' => $c_partners,
                        'r_persons' => $r_persons,
                        'res_p'=> $res_p,

                        'ct_name' => $input['ct_name'],
                        'ct_pos' => $input['ct_pos'],
                        'ct_cell' => $input['ct_cell'],

                ]);
         
//      
        return redirect()->route('dips.edit', $id)->withFlashSuccess('DIP profile is updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $event = DIP::findOrFail($id);
        $event->delete();
        
        return redirect('dips');
    }
}
