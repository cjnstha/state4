<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EvaluationReport extends Model
{
    protected $table = 'evaluation_report';

    protected $guarded = ['id'];
}
