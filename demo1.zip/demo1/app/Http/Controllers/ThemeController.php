<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ThemeLess;

class ThemeController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $posts= ThemeLess::all();
        return view('theme.index', compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
      
        return view('theme.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name' => 'required',
            
        ]);
        ThemeLess::create($request->all());
        return redirect()->route('theme.index')->withFlashSuccess('Theme has been added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $posts = ThemeLess::findOrFail($id);
       
        return view('theme.edit', compact('posts','types'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $this->validate($request,[
            'name' => 'required',
           
        ]);
        $theme = ThemeLess::findOrFail($id);
        $theme->update($request->all());
        return redirect()->route('theme.edit', $id)->withFlashSuccess('Theme profile is updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        ThemeLess::destroy($id);
        return redirect()->route('theme.index')->withFlashSuccess('Theme profile is deleted successfully.');
    }
}
