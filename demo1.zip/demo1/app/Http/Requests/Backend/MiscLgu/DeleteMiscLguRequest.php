<?php

namespace App\Http\Requests\Backend\MiscLgu;

use Illuminate\Foundation\Http\FormRequest;
use Auth;

class DeleteMiscLguRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Auth::user()->can('delete_miscellaneous_lgus');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }
}
