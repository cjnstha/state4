<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MinistryDocuments extends Model
{
    protected $table = 'ministry_documents';

    protected $guarded = ['id'];
}
