<footer>
 <div class="footer-wrap">
     <div class="col-md-6">
     <div class="pull-left">
    {{-- <strong>Supported By: </strong><img src="#" width="30" alt="">  --}}
    </div>
 </div>
    <div class="col-md-6">
        <div class="pull-right">
    <strong>System Developed By: </strong><a href="http://www.3hammers.com" target="_blank"><img src="{{url('footer.png')}}" width="30" alt="" class="footerimg"> </a>
    </div>
    </div>
 </div>
    <div class="clearfix"></div>
</footer>
<style>
    .footerimg{
        height: 25px;
        width: 25px;
        background: #fff;
        border-radius: 50%;
        border: 2px solid #f9f9f9;
    }
</style>