


<!-- ajax -->
 {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js" integrity="sha384-FzT3vTVGXqf7wRfy8k4BiyzvbNfeYjK+frTVqZeNDFl8woCbF0CYG6g2fMEFFo/i" crossorigin="anonymous"></script> --}}
<script type="text/javascript" src="{!! asset('/js/jquery.form.min.js') !!}"></script>
 

<!-- Bootstrap -->
<script type="text/javascript" src="{!! asset('/vendors/bootstrap/dist/js/bootstrap.min.js') !!}"></script>
<!-- FastClick -->
<script type="text/javascript" src="{!! asset('/vendors/fastclick/lib/fastclick.js') !!}"></script>
<!-- NProgress -->
<script type="text/javascript" src="{!! asset('/vendors/nprogress/nprogress.js') !!}"></script>
<!-- Chart.js -->
<script type="text/javascript" src="{!! asset('/vendors/Chart.js/dist/Chart.min.js') !!}"></script>
<!-- gauge.js -->
<script type="text/javascript" src="{!! asset('/vendors/gauge.js/dist/gauge.min.js') !!}"></script>
<!-- bootstrap-progressbar -->
<script type="text/javascript" src="{!! asset('/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js') !!}"></script>
<!-- iCheck -->
<script type="text/javascript" src="{!! asset('/vendors/iCheck/icheck.min.js') !!}"></script>
<!-- Skycons -->
<script type="text/javascript" src="{!! asset('/vendors/skycons/skycons.js') !!}"></script>
<!-- Flot -->
<script type="text/javascript" src="{!! asset('/vendors/Flot/jquery.flot.js') !!}"></script>
<script type="text/javascript" src="{!! asset('/vendors/Flot/jquery.flot.pie.js') !!}"></script>
<script type="text/javascript" src="{!! asset('/vendors/Flot/jquery.flot.time.js') !!}"></script>
<script type="text/javascript" src="{!! asset('/vendors/Flot/jquery.flot.stack.js') !!}"></script>
<script type="text/javascript" src="{!! asset('/vendors/Flot/jquery.flot.resize.js') !!}"></script>
<!-- Flot plugins -->
<script type="text/javascript" src="{!! asset('/vendors/flot.orderbars/js/jquery.flot.orderBars.js') !!}"></script>
<script type="text/javascript" src="{!! asset('/vendors/flot-spline/js/jquery.flot.spline.min.js') !!}"></script>
<script type="text/javascript" src="{!! asset('/vendors/flot.curvedlines/curvedLines.js') !!}"></script>
<!-- DateJS -->
<script type="text/javascript" src="{!! asset('/vendors/DateJS/build/date.js') !!}"></script>
<!-- JQVMap -->
<script type="text/javascript" src="{!! asset('/vendors/jqvmap/dist/jquery.vmap.js') !!}"></script>
<script type="text/javascript" src="{!! asset('/vendors/jqvmap/dist/maps/jquery.vmap.world.js') !!}"></script>
<script type="text/javascript" src="{!! asset('/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js') !!}"></script>
<!-- bootstrap-daterangepicker -->
<script type="text/javascript" src="{!! asset('/vendors/moment/min/moment.min.js') !!}"></script>
<script type="text/javascript" src="{!! asset('/vendors/bootstrap-daterangepicker/daterangepicker.js') !!}"></script>


    <!-- PNotify -->
    <script type="text/javascript" src="{!! asset('/vendors/pnotify/dist/pnotify.js') !!}"></script>
    <script type="text/javascript" src="{!! asset('/vendors/pnotify/dist/pnotify.buttons.js') !!}"></script>
    <script type="text/javascript" src="{!! asset('/vendors/pnotify/dist/pnotify.nonblock.js') !!}"></script>
     <!-- morris.js -->
    <script src="{!! asset('/vendors/raphael/raphael.min.js') !!}"></script>
    <script src="{!! asset('/vendors/morris.js/morris.min.js') !!}"></script>
    <!-- ECharts -->
    <script src="{!! asset('/vendors/echarts/dist/echarts.min.js') !!}"></script>
    <script src="{!! asset('/vendors/echarts/map/js/world.js') !!}"></script>
    
@include('partials.scripts.datatables')









