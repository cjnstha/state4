<link href="{!! asset('/vendors/bootstrap/dist/css/bootstrap.min.css') !!}" rel="stylesheet">
<link href="{!! asset('/vendors/font-awesome/css/font-awesome.min.css') !!}" rel="stylesheet">
<link href="{!! asset('/vendors/nprogress/nprogress.css') !!}" rel="stylesheet">
<link href="{!! asset('/vendors/iCheck/skins/flat/green.css') !!}" rel="stylesheet">
<link href="{!! asset('/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css') !!}" rel="stylesheet">
<link href="{!! asset('/vendors/jqvmap/dist/jqvmap.min.css') !!}" rel="stylesheet"/>
<link href="{!! asset('/vendors/bootstrap-daterangepicker/daterangepicker.css') !!}" rel="stylesheet">


 <!-- PNotify -->
    <link href="{!! asset('/vendors/pnotify/dist/pnotify.css') !!}" rel="stylesheet">
    <link href="{!! asset('/vendors/pnotify/dist/pnotify.buttons.css') !!}" rel="stylesheet">
    <link href="{!! asset('/vendors/pnotify/dist/pnotify.nonblock.css') !!}" rel="stylesheet">

    <link href="{!! asset('/css/bootstrap-datepicker3.css') !!}" rel="stylesheet">

    {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>  --}}
@include('partials.stylesheet.datatables')



<link href="{!! asset('/build/css/custom.min.css') !!}" rel="stylesheet">
<script  src="{!! asset('/vendors/jquery/dist/jquery.min.js') !!}"></script>