<link rel="stylesheet" href="{!! asset('vendors/bootstrap/dist/css/bootstrap.min.css') !!}">
<link rel="stylesheet" href="{!! asset('vendors/font-awesome/css/font-awesome.min.css') !!}">
<link rel="stylesheet" href="{!! asset('vendors/nprogress/nprogress.css') !!}">
<link rel="stylesheet" href="{!! asset('vendors/animate.css/animate.min.css') !!}">
<link rel="stylesheet" href="{!! asset('build/css/custom.min.css') !!}">
{{--<link rel="stylesheet" href="{!! asset('') !!}">--}}
