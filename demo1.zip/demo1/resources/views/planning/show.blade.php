
 

                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12"> Output <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-7 col-xs-12">

                             {!! Form::select('output_id[]', $output ,  null, ['class' => 'form-control','id'=>'outputshow','multiple','required']) !!}

                        </div>
                    </div>

                     

          
