@extends('layouts.master')

@section('content')

    
   

    <div class="x_panel">
        <div class="x_title">
            <h2>Beneficiaries</h2>
            <ul class="nav navbar-right panel_toolbox">
                <li >
                    <span>
                       <a href="{!! route('benef.create') !!}" class="btn btn-primary">
                              Add New Beneficiaries
                          </a>
                   </span>
                </li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <div class="x_content">


            <table id="benef-group-ind-index" class="table table-striped table-bordered display">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Group/Individual</th>
                    <th>Age</th>
                    <th>Age Group</th>                   
                    <th>Gender</th>
                    <th>Group - Gender</th> 
                    <th>Caste</th>
                    <th>Group - Caste</th>
                     <th>Identity</th>
                     <th>Group - Identity</th>
                     <th>Activity</th> 
                    <th>Action</th>
                   
                </tr>
                </thead>

                <tbody>
                    <?php  $i=1; ?>
                @foreach($posts as $p)

                <tr>
                    <td> {{ $i }}</td>
                    <td> {{ $p->name}}</td>
                    <td> {{ $p->benef_type}}</td>
                    <td> {{ $p->age}}</td>
                      <td> 
                    @if ($p->age_below_15 != '' || $p->age_below_15 != 0)   Below 15 : {!! $p->age_below_15 !!} <br>@endif 
                    @if ($p->age_15_29 != '' || $p->age_15_29 != 0) 15-29 : {!! $p->age_15_29 !!} <br> @endif
                    @if ($p->age_30_45 != '' || $p->age_30_45 != 0)  30-45 :  {{ $p->age_30_45 }}  <br>@endif
                    @if ($p->age_45_above != '' || $p->age_45_above != 0)  45-Above : {{ $p->age_45_above }} <br> @endif

                    </td>
                    <td> {{ $p->gender}}</td>
                      <td> 
                      @if ($p->gender_male != '' || $p->gender_male != 0) Male: {{ $p->gender_male }} <br> @endif
                      @if ($p->gender_female != '' || $p->gender_female != 0) Female {{ $p->gender_female }} <br> @endif
                      @if ($p->gender_others != '' || $p->gender_others != 0) Others: {{ $p->gender_others }} <br> @endif
                    </td>
                    <td> {{ isset($p->castes)? $p->castes->name : ''}}</td>
                     <td> 
                        @foreach ($caste as $id => $name)
                          
                            <?php 
                               $value = \DB::table('benef_caste_eth_if_group')
                                                        ->select('cast_eth_value')
                                                        ->where('benef_id',$p->id)
                                                        ->where('caste_eth_id',$id)
                                                        ->first();
                                                        // echo $value->cast_eth_value;
                                // echo isset($value->cast_eth_value)? $value->cast_eth_value: ''; 
                            if(isset($value->cast_eth_value))
                              {

                                echo $name .':'.$value->cast_eth_value.', ';
                              }

                                ?>  
                                    
                        @endforeach 
                       

                    </td>
                     <td> {{ isset($p->identities)? $p->identities->name : ''}}</td>
                     <td>  @foreach($identity as $id => $name)
                             <?php 
                                $value = \DB::table('benef_identity_if_group')
                                                                ->select('identity_value')
                                                                ->where('benef_id',$p->id)
                                                                ->where('identity_id',$id)
                                                                ->first();

                              // echo isset($value->identity_value)? $value->identity_value: ''; 
                              if(isset($value->identity_value))
                              {
                                echo $name .':'.$value->identity_value.', ';
                              }
                              ?>         
                        @endforeach 
                    </td>
                      <td> {{ isset($p->activity)? $p->activity->name : ''}}</td>
                    <td>
                  
                    <a href=" {{ route('benef.edit',$p->id) }}" class="action-btns">
                        <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                    {{Form::open(['route'=>['benef.destroy', $p->id] , 'method'=>'DELETE', 'class'=>'form-inline' ])}}
                        <a href="javascript:void(0);" class="submit action-btns"><span class="glyphicon glyphicon-trash"></span></a>
                    {{Form::close()}}
                  
                    </td>
                </tr>
                <?php $i++; ?>
                @endforeach
                </tbody>
            </table>
        </div>



    </div>



        <div class="row">
            <div class="col-sm-3">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Age Group</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <table class="table table-striped table-bordered">
                            <tr>
                                <th>Age-Group</th>
                             
                               
                              
                                <th>Total</th>
                            </tr>
                            <tr>
                                <th>Below 15</th>
                               
                                <td>{{$age_below_15 }} </td>
                            </tr>
                            <tr>
                                <th>15-29</th>
                             
                                <td>{{$age_15_29 }}</td>
                            </tr>
                            <tr>
                                <th>30-45</th>
                              
                                <td>{{$age_30_45}}</td>
                            </tr>
                            <tr>
                                <th>45-Above</th>
                              
                                <td>{{$age_45_above}}</td>
                            </tr>
                            <tr>
                                <th>Total</th>
                               
                                <td>{{ $age_below_15 + $age_15_29 + $age_30_45 + $age_45_above }}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

                        <div class="col-sm-3">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Gender Group</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <table class="table table-striped table-bordered">
                            <tr>
                                <th>Gender</th>
                             
                               
                              
                                <th>Total</th>
                            </tr>
                            <tr>
                                <th>Male</th>
                               
                                <td>{{$gender_male }} </td>
                            </tr>
                            <tr>
                                <th>Female</th>
                             
                                <td>{{$gender_female }}</td>
                            </tr>
                            <tr>
                                <th>Othes</th>
                              
                                <td>{{$gender_others}}</td>
                            </tr>
                         
                            <tr>
                                <th>Total</th>
                               
                                <td>{{ $gender_male + $gender_female + $gender_others }}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>


                        <div class="col-sm-3">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Identity Group</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <table class="table table-striped table-bordered">
                            <tr>
                                <th>Identity</th>
                                <th>Total</th>
                            </tr>
                        @foreach($identity_count as $name=>$value ) 
                            <tr>
                                <th>  {{ $name }} </th>
                               
                                <td>{{$value  }} </td>
                            </tr>
                        @endforeach
                 
                            <tr>
                                <th>Total</th>
                               
                                <td>{{ $identity_total }}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>



                        <div class="col-sm-3">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Caste Group</h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <table class="table table-striped table-bordered">
                            <tr>
                                <th>Caste</th>
                                <th>Total</th>
                            </tr>
                        @foreach($caste_count as $name=>$value ) 
                            <tr>
                                <th>  {{ $name }} </th>
                               
                                <td>{{$value  }} </td>
                            </tr>
                        @endforeach
                 
                            <tr>
                                <th>Total</th>
                               
                                <td>{{ $caste_total }}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
     
        </div>
       

       

@endsection
