<div class="new-field">
        <input type="hidden" name="benef_id[]" value="{{ $benef_id }}" >
        <input type="text" name="benef_name[]" value="{{ $benef_name }}" class="form-control" readonly="">

        <div id="del_input">
            <span class="glyphicon glyphicon-trash"></span>
        </div>
</div>


